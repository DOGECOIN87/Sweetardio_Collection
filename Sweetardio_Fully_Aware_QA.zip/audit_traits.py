
import cv2, numpy as np, pandas as pd, json
from pathlib import Path

ROOT="traits"
BG={"background","backgrounds","backgrounds_pop","backgroundz"}
SPECIAL={"legendaryz","secret_rarez"}

def metrics(path):
    img=cv2.imread(str(path),cv2.IMREAD_UNCHANGED)
    if img is None: return None
    if img.ndim==2:
        img=cv2.cvtColor(img,cv2.COLOR_GRAY2BGRA)
    if img.shape[2]==4:
        m=img[:,:,3]>10
        rgb=img[:,:,:3]
    else:
        rgb=img
        m=np.ones(rgb.shape[:2],bool)

    hsv=cv2.cvtColor(rgb,cv2.COLOR_BGR2HSV)
    h=hsv[:,:,0].astype(int)*2
    s=hsv[:,:,1]
    v=hsv[:,:,2]

    bright=float(v[m].mean())/255*100
    sat=float(s[m].mean())/255*100

    hero=((h>165)&(h<195)|(h>270)&(h<335))&(s>80)&m
    hero_pct=float(hero.sum())/max(1,m.sum())*100

    return bright,sat,hero_pct

rows=[]
for ext in ("*.png","*.webp"):
    for f in Path(ROOT).rglob(ext):
        r=metrics(f)
        if not r: continue
        b,s,h=r
        cat=f.parent.name.lower()

        if cat in BG:
            score=100-max(0,b-45)*1.5-max(0,s-40)-max(0,h-15)*2
        elif cat=="eyez":
            score=min(100,60+h)
        elif cat in ("skinz","armz","mouthz"):
            score=100-abs(b-55)
        else:
            score=min(100,50+h)

        rows.append([str(f),cat,round(b,2),round(s,2),round(h,2),round(score,2)])

df=pd.DataFrame(rows,columns=["file","category","brightness","saturation","hero_pct","score"])
df["status"]=df.score.apply(lambda x:"PASS" if x>=80 else "WARNING" if x>=60 else "FAIL")

Path("qa_reports").mkdir(exist_ok=True)
df.sort_values("score").to_csv("qa_reports/ranked_rework_list.csv",index=False)
df.to_json("qa_reports/report.json",orient="records",indent=2)
print("Analyzed",len(df),"assets")
