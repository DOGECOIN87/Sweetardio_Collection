
import cv2, numpy as np
from pathlib import Path

ROOT=Path("traits")
OUT=Path("corrected_traits")

BG={"background","backgrounds","backgrounds_pop","backgroundz"}

for f in ROOT.rglob("*.png"):
    img=cv2.imread(str(f),cv2.IMREAD_UNCHANGED)
    if img is None: continue

    cat=f.parent.name.lower()

    if cat in BG:
        rgb=img[:,:,:3] if img.shape[2]==4 else img
        hsv=cv2.cvtColor(rgb,cv2.COLOR_BGR2HSV)
        hsv[:,:,1]=(hsv[:,:,1]*0.88).clip(0,255).astype("uint8")
        hsv[:,:,2]=(hsv[:,:,2]*0.82).clip(0,255).astype("uint8")
        rgb=cv2.cvtColor(hsv,cv2.COLOR_HSV2BGR)
        if img.shape[2]==4: img[:,:,:3]=rgb
        else: img=rgb

    rel=f.relative_to(ROOT)
    out=OUT/rel
    out.parent.mkdir(parents=True,exist_ok=True)
    cv2.imwrite(str(out),img)
