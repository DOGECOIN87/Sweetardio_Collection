
import pandas as pd
df=pd.read_csv("qa_reports/ranked_rework_list.csv")
print(df.groupby("category")["score"].mean().sort_values())
print(df.head(50))
